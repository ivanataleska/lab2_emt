package com.example.emt_lab2.model.exceptions;

public class AuthorIdNotFoundException extends RuntimeException{
    public AuthorIdNotFoundException(Long id) {
        super(String.format("The author with this %d id was not found!",id));
    }
}
