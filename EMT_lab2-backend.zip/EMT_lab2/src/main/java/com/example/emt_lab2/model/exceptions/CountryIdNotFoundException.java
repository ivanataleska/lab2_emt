package com.example.emt_lab2.model.exceptions;

public class CountryIdNotFoundException extends RuntimeException{
    public CountryIdNotFoundException(Long id) {
        super(String.format("The country with this %d id was not found!",id));
    }
}
