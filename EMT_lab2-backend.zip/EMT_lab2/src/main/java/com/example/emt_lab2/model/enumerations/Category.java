package com.example.emt_lab2.model.enumerations;

public enum Category {
    NOVEL, THRILER, HISTORY, FANTASY, BIOGRAPHY, CLASSICS, DRAMA
}
