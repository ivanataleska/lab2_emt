package com.example.emt_lab2.web.restControllers;

import com.example.emt_lab2.model.enumerations.Category;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.List;

@RestController
@CrossOrigin(origins = "http://localhost:3000")
@RequestMapping("/api/categories")
public class CategoriesRestController {

    @GetMapping
    public List<Category> getCategories(){
        List<Category> categories = new ArrayList<>();

        categories.add(Category.BIOGRAPHY);
        categories.add(Category.CLASSICS);
        categories.add(Category.DRAMA);
        categories.add(Category.HISTORY);
        categories.add(Category.FANTASY);
        categories.add(Category.NOVEL);
        categories.add(Category.THRILER);
        return categories;
    }
}
