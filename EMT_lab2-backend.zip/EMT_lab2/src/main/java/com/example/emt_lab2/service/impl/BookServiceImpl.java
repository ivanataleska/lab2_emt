package com.example.emt_lab2.service.impl;

import com.example.emt_lab2.model.Author;
import com.example.emt_lab2.model.Book;
import com.example.emt_lab2.model.Dto.BookDto;
import com.example.emt_lab2.model.enumerations.Category;
import com.example.emt_lab2.model.exceptions.AuthorIdNotFoundException;
import com.example.emt_lab2.model.exceptions.BookIdNotExistException;
import com.example.emt_lab2.repository.AuthorRepository;
import com.example.emt_lab2.repository.BookRepository;
import com.example.emt_lab2.repository.CountryRepository;
import com.example.emt_lab2.service.BookService;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class BookServiceImpl implements BookService {

    private final BookRepository bookRepository;
    private final AuthorRepository authorRepository;
    private final CountryRepository countryRepository;

    public BookServiceImpl(BookRepository bookRepository, AuthorRepository authorRepository, CountryRepository countryRepository) {
        this.bookRepository = bookRepository;
        this.authorRepository = authorRepository;
        this.countryRepository = countryRepository;
    }


    @Override
    public List<Book> findAll() {
        return this.bookRepository.findAll();
    }

    @Override
    public Optional<Book> findById(Long id) {
        return this.bookRepository.findById(id);
    }

    @Override
    public Book create(String name, Category category, Long authorId, Integer avalibleCopies) {
        Author author = this.authorRepository.findById(authorId).orElseThrow(()->new AuthorIdNotFoundException(authorId));

        Book book =  new Book(name,category,author,avalibleCopies);
        return this.bookRepository.save(book);

    }

    @Override
    public Optional<Book> save(BookDto bookDto) {
        Author author = this.authorRepository.findById(bookDto.getAuthor()).orElseThrow(()->new AuthorIdNotFoundException(bookDto.getAuthor()));
        Book book = new Book(bookDto.getName(),bookDto.getCategory(),author,bookDto.getAvalibleCopies());
        return Optional.of(this.bookRepository.save(book));

    }

    @Override
    public Optional<Book> edit(Long id, BookDto bookDto) {
        Book book = this.bookRepository.findById(id).orElseThrow(()->new BookIdNotExistException(id));
        book.setName(bookDto.getName());
        book.setCategory(bookDto.getCategory());
       book.setAvalibleCopies(bookDto.getAvalibleCopies());
        Author author = this.authorRepository.findById(bookDto.getAuthor()).orElseThrow(()->new AuthorIdNotFoundException(bookDto.getAuthor()));
        book.setAuthor(author);
        this.bookRepository.save(book);
        return Optional.of(book);

    }

    @Override
    public void deleteById(Long id) {
        this.bookRepository.deleteById(id);
    }

    @Override
    public Book MarkAsTaken(Long id) {
        Optional<Book> book = this.findById(id);
        Integer avalibleCopies = book.get().getAvalibleCopies() - 1;
        if(avalibleCopies<=0){
            book.get().setAvalibleCopies(0);
        }
        else {book.get().setAvalibleCopies(avalibleCopies);}

        return this.bookRepository.save(book.get());
    }
}
