package com.example.emt_lab2.model.Dto;

import com.example.emt_lab2.model.Author;
import com.example.emt_lab2.model.enumerations.Category;
import lombok.Data;

import javax.persistence.ManyToOne;

@Data
public class BookDto {

    private String name;
    private Category category;
    @ManyToOne
    private Long author;
    private Integer avalibleCopies;


    public BookDto() {
    }

    public BookDto(String name, Category category, Long author, Integer avalibleCopies) {
        this.name = name;
        this.category = category;
        this.author = author;
        this.avalibleCopies = avalibleCopies;
    }
}
