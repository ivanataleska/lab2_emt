package com.example.emt_lab2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmtLab2Application {

    public static void main(String[] args) {
        SpringApplication.run(EmtLab2Application.class, args);
    }

}
