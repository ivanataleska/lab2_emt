import axios from '../custom-axios/axios';

const LibraryService = {
    fetchBooks: () => {
        return axios.get("/books",{
            params: {
                size: 5,
                batch: 2
            }
        });
    },
    deleteBook: (id) => {
        return axios.delete(`/books/delete/${id}`);
    },
    editBook:(id,name, category, author, avalibleCopies) => {
        return axios.put(`/books/edit/${id}`,{
            "name" : name,
            "category" : category,
            "author" : author,
            "avalibleCopies" : avalibleCopies,
        });
    },
    getBook: (id) => {
        return axios.get(`/books/${id}`)
    },
    fetchCategories: () => {
        return axios.get("/categories");
    },
    fetchAuthors: () => {
        return axios.get("/authors");
    },
    addBook:(name, category, author, avalibleCopies) => {
        return axios.post(`/books/add/`,{
            "name" : name,
            "category" : category,
            "author" : author,
            "avalibleCopies" : avalibleCopies,
        });
    },
    markAsTaken: (id) =>{
        return axios.put(`/books/markAsTaken/${id}`)
    }
}
export default LibraryService;