package com.example.emt_lab2.model;

import com.example.emt_lab2.model.enumerations.Category;
import lombok.Data;

import javax.persistence.*;

@Data
@Entity
public class Book {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String name;
    @Enumerated(EnumType.STRING)
    private Category category;
    @ManyToOne
    private Author author;
    private Integer avalibleCopies;

    public Book() {
    }

    public Book(String name, Category category, Author author, Integer avalibleCopies) {
        this.name = name;
        this.category = category;
        this.author = author;
        this.avalibleCopies = avalibleCopies;
    }
}
