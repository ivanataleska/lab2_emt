package com.example.emt_lab2;

import org.junit.Test;


class EmtLab2ApplicationTests {

    @Test
    void contextLoads() {
    }

}
