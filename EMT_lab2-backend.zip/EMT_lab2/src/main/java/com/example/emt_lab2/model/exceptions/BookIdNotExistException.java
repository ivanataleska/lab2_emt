package com.example.emt_lab2.model.exceptions;

public class BookIdNotExistException extends RuntimeException {
    public BookIdNotExistException(Long id) {
        super(String.format("The book with this %d id was not found!",id));
    }
}
