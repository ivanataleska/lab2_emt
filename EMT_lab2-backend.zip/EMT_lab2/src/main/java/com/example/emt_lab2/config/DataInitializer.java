package com.example.emt_lab2.config;

import com.example.emt_lab2.model.Author;
import com.example.emt_lab2.model.Country;
import com.example.emt_lab2.model.enumerations.Category;
import com.example.emt_lab2.service.AuthorService;
import com.example.emt_lab2.service.BookService;
import com.example.emt_lab2.service.CountryService;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.util.List;

@Component
public class DataInitializer {

    private final BookService bookService;

    private final AuthorService authorService;

    private final CountryService countryService;

    public DataInitializer(BookService bookService, AuthorService authorService, CountryService countryService) {
        this.bookService = bookService;
        this.authorService = authorService;
        this.countryService = countryService;
    }

    @PostConstruct
    public void initData()
    {
        this.countryService.create("Macedonia","Europe");
        this.countryService.create("Serbia","Europe");
        this.countryService.create("Russia","Asia");

       List<Country> countryList = this.countryService.findAll();

       this.authorService.create("Sreten","Strezovski",countryList.get(0).getId());
        this.authorService.create("Marko","Nikoloski",countryList.get(1).getId());
        this.authorService.create("Stojce","Stojanov",countryList.get(2).getId());

        List<Author> authors = this.authorService.findAll();

        this.bookService.create("Izlez",Category.DRAMA,authors.get(0).getId(),3);
        this.bookService.create("Motivation",Category.CLASSICS,authors.get(1).getId(),6);
        this.bookService.create("Nature",Category.BIOGRAPHY,authors.get(2).getId(),2);



    }
}
